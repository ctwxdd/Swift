class BST <T : Comparable> {
    
    var key : T?
    var left : BST?
    var right : BST?
    
    func addNode (key : T){
        
        if(self.key == nil){
            self.key = key
            return
        }
        
        if(key < self.key) {
            
            if (self.left != nil) {
                
                self.left!.addNode(key)
                
            }else{
                
                
                let leaf = BST<T>()
                
                leaf.key = key
                
                self.left = leaf
            }
            
        } else if (key > self.key){
            
            
            if(self.right != nil){
                
                self.right?.addNode(key)
                
            }else {
                
                let leaf = BST<T>()
                
                leaf.key = key
                
                self.right = leaf
            }
        }
    }
    
}//end bst class 

let num = [8, 2, 10, 9, 11, 1, 7]

var root = BST<Int>()

for n in num {
    
    root.addNode(n)
}
