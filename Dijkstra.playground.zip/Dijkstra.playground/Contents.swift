class Vertex {
    
    var key : String?
    var neighbors : Array<Path>
    var distance = Int.max
    //If the vertex has been visted
    var conquered : Bool
    //remember the path from the source
    var path : String?
    
    init() {
        
        self.neighbors = Array<Path>()
        self.conquered = false
    }

    
}

class Path {
    
    var weight: Int
    var destination : Vertex?
    var previous : Vertex?
    
    init (){
        
    weight = Int.max
        
    }

    init ( from : Vertex, to : Vertex, weight : Int){
        
        self.weight = weight
        self.destination = to
        self.previous = from
    }
}

class Graph {
    
    var vertex: [String : Vertex] = [:]

    func addPath(from : String, to : String, weight : Int ){
        
        var source : Vertex
        var destination : Vertex
        
        if (vertex[from] == nil){
            
            let newVertex = Vertex()
            newVertex.key = from
            vertex[from] = newVertex
            
        }
        
        if (vertex[to] == nil) {
            
            let newVertex = Vertex()
            newVertex.key = to
            vertex[to] = newVertex
        }
        
        source      = vertex[from]!
        destination = vertex[to]!
        
        let newPath = Path(from: source, to : destination, weight: weight)
        source.neighbors.append(newPath)
        
    }
    
    //find the shortest path from source to destination
    func dijkstra(from : String , to : String) -> (Int, String) {
        
        var frontier = Array<Path>()
        
        if self.vertex[from] == nil {
            return (-1, "no path")
        }
        
        self.vertex[from]?.conquered = true
        self.vertex[from]?.distance = 0
        self.vertex[from]?.path = from
        
        for path in (self.vertex[from]?.neighbors)! {

            path.destination!.distance = path.weight
            frontier.append(path)
            
        }
        
        while(frontier.count > 0){
            
            var bestPath: Path  = Path()
            var index: Int      = 0
            var cnt: Int        = 0
            //find the best path
            for e in frontier{
                
                if (bestPath.destination == nil || e.weight < bestPath.weight){
                    
                    bestPath = e
                }
                
            }// end for
            
            
            bestPath.destination?.distance = (bestPath.previous?.distance)! + (bestPath.weight)
            bestPath.destination?.path = (bestPath.previous?.path)!+" -> "+(bestPath.destination?.key)!
            bestPath.destination?.conquered = true
        
            // find the number of paths that direct to the conquered vertex
            for i in frontier {
                
                if i.destination?.conquered == true{
                    
                    cnt += 1
                }
            }
                        
            // Remove all path to the conquered vertex
            // Must be improved
            
            while(cnt>0){
                
                index = 0
                
                for i in 0..<frontier.count{
                    
                    if frontier[i].destination?.conquered == true{
                        
                        index = i
                        break
                    }
                }
                
                frontier.removeAtIndex(index)
                cnt -= 1
                
            }
            
            // Add all the neighbors of the new added vertex to frontier
            
            for e in (bestPath.destination!.neighbors) {
            
                if e.destination!.conquered == false {
                    
                    frontier.append(e)
                }
                
            }
            
        }//end while
        
        return ((self.vertex[to]?.distance)!, (self.vertex[to]?.path)!)
        
    }//end dijkstra
}


var graph = Graph()

graph.addPath("A", to: "B", weight: 1)
graph.addPath("B", to: "C", weight: 1)
graph.addPath("A", to: "C", weight: 3)
graph.addPath("A", to: "D", weight: 4)
graph.addPath("C", to: "D", weight: 1)
graph.addPath("D", to: "A", weight: 5)
graph.addPath("C", to: "E", weight: 5)


var distance: Int
var path : String


(distance, path) = graph.dijkstra("A", to: "E")

print("The shortest ditance from A to E is \(distance)")
print("The path is : \(path)")


