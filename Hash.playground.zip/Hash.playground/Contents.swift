class HashNode {
    
    var firstName: String!
    var lastname: String!
    var next : HashNode!
    
}

class HashTable {
    
    var bucket: Array<HashNode?>
    
    init(capacity : Int){
        
        self.bucket = Array<HashNode?>(count: capacity, repeatedValue: nil)
    }
    
    
    //add word into the bucket
    
    func addWord (firstname : String, lastname : String) {
        
        var hashindex : Int
        var fullname : String
        
        fullname = firstname + lastname
        hashindex = self.createHash(fullname)
        
        let childToUse: HashNode = HashNode()
        var head: HashNode
        
        childToUse.firstName = firstname
        childToUse.lastname = lastname
        
        if (bucket[hashindex] == nil){
            bucket[hashindex] = childToUse
        }else {
            print("a collision occured. Implementing chaining..")
            
            head = bucket[hashindex]!
            childToUse.next = head
            
            bucket[hashindex] = childToUse
        }
    }
    
    //calculate the hash value for a fullname
    func createHash(fullname : String) -> Int{
        var remainder : Int = 0
        var divisor : Int = 0
        
        for key in fullname.unicodeScalars {
            divisor += Int(key.value)
        }
        
        remainder = divisor % bucket.count
        return remainder
    }
}


var hashTable = HashTable(capacity: 10)

hashTable.addWord("Nick", lastname: "Wu")
hashTable.addWord("Steve", lastname: "Jobs")

for (i, hashnode) in hashTable.bucket.enumerate(){
    
    if (hashnode != nil){
        print ("Index \(i), Nmae: \(hashnode!.firstName)")
    }
}

