import Darwin

class Heap <T : Comparable>{
    
    var heap : Array<T> = Array<T>()
    var rear : Int = 0
    var head : T {
        get {
            return heap[0]
        }
    }
    func addNode(newNode: T) {
        
        heap.append(newNode)
        var childIndex: Int = heap.endIndex - 1
        var parentIndex: Int = (childIndex-1) / 2
        
        if heap.count == 1 {return}
        
        while(heap[childIndex]<heap[parentIndex]){
            
            let temp = heap[childIndex]
            heap[childIndex] = heap[parentIndex]
            heap[parentIndex] = temp
            
            childIndex = parentIndex
            parentIndex = (parentIndex - 1) / 2
            
            if parentIndex < 0 {break}
            
        }
        
    }

    func removeHead(){
     
        var currentIndex = 0
        
        heap[0] = heap[heap.endIndex-1]
        heap.removeAtIndex(heap.endIndex - 1)
        
        var lChildIndex = currentIndex * 2 + 1
        var rChildIndex = currentIndex * 2 + 2
        
        while( lChildIndex < heap.endIndex || rChildIndex < heap.endIndex){
            
            var changeIndex = lChildIndex
            
            //Prevent index out of range
            
            if  ( rChildIndex < heap.endIndex){
                
                if(heap[rChildIndex] < heap[lChildIndex]){
                    changeIndex = rChildIndex
                }
            }
            
            if(heap[currentIndex]<heap[changeIndex]){break}
            
            let tmp = heap[currentIndex]
            heap[currentIndex] = heap[changeIndex]
            heap[changeIndex] = tmp
            
            currentIndex = changeIndex
            lChildIndex = currentIndex * 2 + 1
            rChildIndex = currentIndex * 2 + 2
            
            
        }
    }
    
}

var heap = Heap<Int>()

var num = [1,9,7,2,8,3,5,6,4]

for i in num {
    heap.addNode(i)
}

// get the smallest from heap
while(heap.heap.count > 0){
    
    print(heap.head, terminator: " ")
    heap.removeHead()
    
}

for i in heap.heap{
    print(i, terminator : " ")
}

