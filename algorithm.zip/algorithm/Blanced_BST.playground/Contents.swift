class BST <T : Comparable> {
    
    var key : T?
    var left : BST?
    var right : BST?
    
    func addNode (key : T){
        
        if(self.key == nil){
            self.key = key
            return
        }
        
        if(key < self.key) {
            
            if (self.left != nil) {
                
                self.left!.addNode(key)
                
            }else{
                
                
                let leaf = BST<T>()
                
                leaf.key = key
                
                self.left = leaf
            }
            
        } else if (key > self.key){
            
            
            if(self.right != nil){
                
                self.right?.addNode(key)
                
            }else {
                
                let leaf = BST<T>()
                
                leaf.key = key
                
                self.right = leaf
            }
        }
    }
    
    func getHeight() -> Int{
        
        
        if(self.left == nil && self.right == nil){
            return 0
        }
        
        var leftHeight = -1
        var rightHeight = -1
        
        if let hL = self.left?.getHeight() {
            
            leftHeight = hL
        }
        
        if let rL = self.right?.getHeight(){
            
            rightHeight = rL
        }

        return (max(rightHeight, leftHeight) + 1)
    }
    
    func balance(){
        
        let tmp : BST<T> = BST()
        var leftHeight = -1
        var rightHeight = -1
        
        if let hL = self.left?.getHeight() {
            
            leftHeight = hL
        }
        
        
        if let rL = self.right?.getHeight(){
            
            rightHeight = rL
        }
        
        
        if(abs(leftHeight - rightHeight) > 1) {
            
            tmp.key = self.key
            tmp.left = self.left?.right
            tmp.right = self.right
            
            if(leftHeight - rightHeight)>1 {
                
                self.key = self.left?.key
                self.left = self.left?.left
                self.right = tmp
                
                
            }
            
            if(leftHeight - rightHeight) < -1 {
                
                self.key = self.right?.key
                self.right = self.right?.right
                self.left = tmp
                
                
            }
            
        }
    }
    
}//end bst class 



let num = [8, 7, 6, 5, 4, 3, 2]

var root = BST<Int>()

for n in num {
    
    root.addNode(n)
    root.balance()
    
}

//           5
//          /\
//         4  6
//        /    \
//       3      7
//      /        \
//     2          8

//root.addNode(8)
//print(root.key)
//root.addNode(7)
//print(root.key)
//root.addNode(6)
//root.balance()
print(root.key)
print(root.right?.key)
print(root.left?.key)


root.left?.balance()

//           5
//          /\
//         3  6
//        / \  \
//       2   4  7
//               \
//                8

print(root.left?.key)


