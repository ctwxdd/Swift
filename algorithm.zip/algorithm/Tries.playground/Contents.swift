class TrieNode {
    
    var key : String?
    var children : Array<TrieNode>
    var isFinal : Bool
    var level : Int
    
    init() {
    
        self.children = Array<TrieNode>()
        self.isFinal = false
        self.level = 0
    }
}

class Trie {
    
    var root : TrieNode
    
    init(){
        
        root = TrieNode()
        
    }
    
    func addWord(keyword : String) {
        
        if(keyword.characters.count == 0) {
            return
        }
        
        var current : TrieNode = root
        var searchKey: String?
        
        while(keyword.characters.count != current.level) {
            
            var childToUse : TrieNode?
            
            searchKey = String(keyword.characters.prefix(current.level+1))
            
            for child in current.children {
                if (child.key == searchKey){
                childToUse = child
                    break
                }
            }//end for
            
            if (childToUse == nil) {
                
                childToUse = TrieNode()
                childToUse!.key = searchKey
                childToUse!.level = current.level + 1
                current.children.append(childToUse!)
            }
            
            current = childToUse!
        }//end while
        
        
        if(keyword.characters.count == current.level){
            
            current.isFinal = true
            return
        }
    }
    
    func findWord(keyword : String) ->  Array<String>! {
        
        if(keyword.characters.count == 0){
            return nil
        }
        
        var current = self.root
        var searchKey : String?
        var wordList : Array<String>! = Array<String>()
        
        while(keyword.characters.count != current.level){
            
            var childToUse: TrieNode?
            var searchKey = String(keyword.characters.prefix(current.level+1))
            

            for child in current.children {
                
                if child.key == searchKey {

                    childToUse = child
                    current = childToUse!
                    break
                    
            }//end if
                
        }//end for
            

            if childToUse == nil {
                return nil
            }
        }
        
        
        //find all word with pririx "keyword"
        
        func dfs (node: TrieNode) {
            
                if(node.isFinal == true){
                    
                    wordList.append(node.key!)
                }
                
                for item in node.children {
                    
                    dfs(item)
                }
                
                return
                
            }
        
        dfs(current)
        
        return wordList
            
        
}
    
}

//initialize

var tries : Trie =  Trie()
var list : Array<String>? = Array<String>()

tries.addWord("a")
tries.addWord("aa")
tries.addWord("ab")
tries.addWord("abc")
tries.addWord("aacd")
tries.addWord("aadd")
tries.addWord("abcd")

list = tries.findWord("aa")

if list == nil {
    
    print("Not found.")
    
}else {

    for i in list! {
        print (i)
    }
}
