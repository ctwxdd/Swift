class LinkListNode<T> {
    
    var key : T?
    var next : LinkListNode?
    var previous : LinkListNode?
    
    
    init(){}
    
    init(key: T){
        self.key = key
    }
    //all can be nill
}


//Linklist class 

class LinkList<T : Equatable>{
    
    //defind the entry of the linklist
    
    var head : LinkListNode<T>= LinkListNode<T>()
    
    // Remember the number of link in the linklist
    var totalLink = 0
    
    
    //print all item in the linklist 
    
    func printLinkList() {
        
        var currentNode : LinkListNode = LinkListNode<T>()
        
        
        currentNode = self.head
        
        while(currentNode.key != nil)
        {
            print(currentNode.key!, terminator: " ")
            
            if currentNode.next == nil {
                
                break
                
            }else {
            
            currentNode=currentNode.next!
                
            }
        }
        print("")
        
    }//print LinkList end
    
    
    // add node to the linklist 
    
    func addLink(key : T) {
        
        if head.key == nil{
            
            head.key = key
            totalLink = 1
            return
            
        }else {
            
            var current: LinkListNode<T>? = head
            
            let childToUse : LinkListNode<T> = LinkListNode<T>(key: key)
            
            while(current?.next != nil){
                
                current = current?.next
            }
            
            current?.next = childToUse
            
            childToUse.previous = current
            
            totalLink += 1
            
        }
        
        
    }// add node end
    
    
    //delete node from the linklist 
    
    func deleteLinkFromIndex(index : Int) {
        
        
        var current : LinkListNode<T>? = head
        var currentIndex = 0
        
        if(index == 0){
            
            head = head.next!
            head.previous = nil
        }
        
        if(totalLink < index+1){
            
            print("Out of range.")
        }
        
        while(currentIndex < index){
            
            current = current?.next
            currentIndex += 1
            
        }
        
        current?.previous?.next = current?.next
        current?.next?.previous = current?.previous
        
        totalLink -= 1
        
    }
}



var list : LinkList<Int> = LinkList<Int>()

list.addLink(3)
list.addLink(4)
list.addLink(5)
list.addLink(6)
list.addLink(7)

list.printLinkList()
list.deleteLinkFromIndex(3)
list.printLinkList()


print(list.totalLink)


